package com.cg.banking.services;

import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.execptions.AccountBlockedException;
import com.cg.banking.execptions.AccountNotFoundException;
import com.cg.banking.execptions.BankingServicesDownException;
import com.cg.banking.execptions.InsufficientAmountException;
import com.cg.banking.execptions.InvalidAccountException;
import com.cg.banking.execptions.InvalidAmountException;
import com.cg.banking.execptions.InvalidPinNumberException;

public interface BankingServices {

	Account openAccount(String accountType,float initBalance)
			throws InvalidAmountException,InvalidAccountException,BankingServicesDownException;
	
	float depositAmount(long accountNo,float amount)
			throws AccountNotFoundException,BankingServicesDownException,AccountBlockedException;
	float withdrawAmount(long accountNo,float amount,int pinNumber) throws AccountNotFoundException,InvalidPinNumberException,InsufficientAmountException, AccountBlockedException, BankingServicesDownException;
	
	boolean fundTransfer(long accountNoTo,long accountNoFrom,float transferAmount,int pinNumber) 
			throws InsufficientAmountException,AccountNotFoundException,InvalidPinNumberException,BankingServicesDownException,AccountBlockedException;
	
	Account getAccountDetails(long accountNo) 
			throws BankingServicesDownException,AccountNotFoundException;
	
	List<Account> getAllAccountDetails() 
			throws BankingServicesDownException;
	
	List<Transaction> getAccountAllTransaction(long accountNo) 
			throws BankingServicesDownException;
	
	public String accountStatus(long accountNo )
			throws BankingServicesDownException,AccountNotFoundException,AccountBlockedException;
	
	
	
	
	
	
}
