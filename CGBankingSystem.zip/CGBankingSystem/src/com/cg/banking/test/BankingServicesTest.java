package com.cg.banking.test;

import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.execptions.AccountBlockedException;
import com.cg.banking.execptions.AccountNotFoundException;
import com.cg.banking.execptions.BankingServicesDownException;
import com.cg.banking.execptions.InsufficientAmountException;
import com.cg.banking.execptions.InvalidAccountException;
import com.cg.banking.execptions.InvalidAmountException;
import com.cg.banking.execptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
import com.cg.banking.util.BankingDBUtil;

public class BankingServicesTest {

	private static BankingServices services;
	@BeforeClass
	public static void setUpTestEnv() {
		services=new BankingServicesImpl() ;
	}
	@Before
	public void setUpTestData() {
		Account account1=new Account(101, 2453, "Active", "Savings", 20000);
		Account account2=new Account(102, 1235, "Blocked", "Savings", 5000);
	   BankingDBUtil.accounts.put(account1.getAccountNo(),account1);
	   BankingDBUtil.accounts.put(account2.getAccountNo(), account2);
	   BankingDBUtil.ACCOUNT_NUMBER_COUNTER=102;
	}
	@Test
	public void testDepositAmountForValidAccountNumber() {
		Account account=new Account(101, 2453, "Active", "Savings", 20000);
		try {
			account.setAccountBalance(services.depositAmount(account.getAccountNo(), 20000));
			int expectedamount=(int)account.getAccountBalance();
			int actualAmount=10000;
			Assert.assertEquals(expectedamount, actualAmount);

		} catch (AccountNotFoundException e) {
		e.printStackTrace();
		} catch (BankingServicesDownException e) {
			e.printStackTrace();
		} catch (AccountBlockedException e) {
			e.printStackTrace();
		}
			}
	@Test(expected=AccountNotFoundException.class)
	public void testDepositAmountForInvalidAccountNumber() throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
			services.depositAmount(235, 50000);
		}
	@Test
	public void testWithdrawAmountForValidAcountNumber() throws AccountNotFoundException, InvalidPinNumberException, InsufficientAmountException, AccountBlockedException, BankingServicesDownException {
		Account account=new Account(101, 2453, "Active", "Savings", 20000);
		account.setAccountBalance(services.withdrawAmount(account.getAccountNo(),10000,account.getPinNumber()));
	   int expectedamount=(int)account.getAccountBalance();
	   int actualamount=10000;
	   Assert.assertEquals(expectedamount, actualamount);
	}
	
	
	
}
